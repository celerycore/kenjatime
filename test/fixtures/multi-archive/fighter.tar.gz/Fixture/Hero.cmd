[Command]
name="x"
command=x
[Statedef -1]